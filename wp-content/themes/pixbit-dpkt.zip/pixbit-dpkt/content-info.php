<?php
/*
 * Template Name: Info Page
 */
get_header();
?>
<?php if(get_field('sections')): ?>
	<div class="sections-wrapper">
		<?php $section_counter = 0; ?>
  	<?php
  	while(has_sub_field('sections')):
  		include(locate_template('parts/section-'.get_row_layout().'.php'));
  		$section_counter++;
    endwhile;
    ?>
	</div><!-- .sections-wrapper -->
<?php endif; ?>

<div class='form-block-section row'>
	<h3 class="large-6 columns">Inquiries</h3>
	<h3 class="large-6 columns">Sign up for our newsletter</h3>
	<div class="large-6 columns">
		<ul class="contact-texts">
			<li><span>Talk</span>919-473-6613</li>
			<li><span>Type</span>hello@workbyremedy.co</li>
		</ul>
		
		<h3 class="form-icons-header">Elsewhere</h3>			
		<ul class='form-icons large-block-grid-4'>
			<li class='form-icon'>
				<a class="twitter" href="#" onclick="popUp=window.open('https://twitter.com/share?url=<?php echo $url; ?>&amp;text=<?php echo $text; ?>&amp;hashtags=<?php echo $hashtags; ?>', 'popupwindow', 'scrollbars=yes,width=800,height=400');popUp.focus();return false">Twitter</a>
			</li>
			<li class='form-icon'>
				<a class="google-plus" href="#" onclick="popUp=window.open('https://plus.google.com/share?url=<?php the_permalink(); ?>', 'popupwindow', 'scrollbars=yes,width=800,height=400');popUp.focus();return false">Google Plus</a>
			</li>
			<li class='form-icon'>
				<a class="pinterest pin-it-button" href="#" onclick="popUp=window.open('http://pinterest.com/pin/create/button/?url=<?php echo $url; ?>&amp;media=<?php echo $image; ?>&amp;description=<?php echo $text; ?>', 'popupwindow', 'scrollbars=yes,width=800,height=400');popUp.focus();return false"></a>
			</li>
			<li class='form-icon'>
				<a class="facebook" title="Share on Facebook" href="#fb" onclick="popUp=window.open('http://www.facebook.com/sharer.php?s=100&amp;p[title]=Remedy&amp;p[summary]=<?php echo $text; ?>&amp;u=<?php echo $url; ?>&amp;p[images[0]=<?php echo $image; ?>', 'popupwindow', 'scrollbars=yes,width=800,height=400');popUp.focus();return false">Facebook</a>		
			</li>
		</ul><!-- .share-icons -->
	</div>
	<div class="large-6 columns">
	<?php 
	  $form = get_field('form');
	  gravity_form_enqueue_scripts($form->id, true);
	  gravity_form($form->id, false, false, false, '', true, 1); 
	?>
	</div>
</div>

<?php get_footer(); ?>