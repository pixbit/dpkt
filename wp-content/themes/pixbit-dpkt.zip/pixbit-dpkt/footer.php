</article>
<footer>
	<div class="row">
		<ul>
			<li class='left-footnote large-6 columns'>&copy; 2014 Remedy Co. LLC</li>
			<li class='right-footnote large-6 columns'>Site by Pixbit</li>
		</ul>			
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>